#include <magnetic_tf_pub.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <logger.h>

using namespace std;
#define SIGN(n) (n <= 0?( n < 0 ?-1:0):1)
#define RadianToAngle(X) ((X)*180.0/M_PI)
#define AngleToRadian(X) ((X)*M_PI/180.0)

MagneticTfPub::MagneticTfPub()
    : nh_()
    , task_switch_sub_()
    , magnetic_head_sub_()
    , magnetic_tail_sub_()
    , magnetic_detect_status_pub_()
    , magnetic_head_pose2d_()
    , magnetic_tail_pose2d_()
    , magnetic_head_is_forward_(true)
    , magnetic_tail_is_forward_(true)
    , count_detected_tail_marker_(true)
    , count_detected_head_marker_(true)
    , can_detected_tail_marker_(false)
    , can_detected_head_marker_(false)
    , detected_tail_marker_times_(0)
    , detected_head_marker_times_(0)
    , param_test_(0.0)
    , head_or_tail_(NON)
    , run_task_(false)
    , need_recod_marker_pose_in_odom_(true)
    , head_detected_magnetic_(false)
    , tail_detected_magnetic_(false)
    , odometry_marker_start_()
    , odometry_marker_end_()
    , get_marker_middle_pose_(false)
{
    odom_sub_ = nh_.subscribe("/odom", 1, &MagneticTfPub::OdomCallback, this);
    task_switch_sub_ = nh_.subscribe("/task_switch", 1, &MagneticTfPub::TaskSwitchCallback, this );
    magnetic_head_sub_ = nh_.subscribe("/magnetic_head_data", 1, &MagneticTfPub::MagneticHeadCallback, this);
    magnetic_tail_sub_ = nh_.subscribe("/magnetic_tail_data", 1, &MagneticTfPub::MagneticTailCallback, this);

    magnetic_detect_status_pub_ = nh_.advertise<std_msgs::Bool>("/magnetic_detected", 1);

    ros::NodeHandle nh_p("~");
    double distance_magnetic_head_to_robot_center;
    double distance_magnetic_tail_to_robot_center;
    
    nh_p.param("magnetic_head_is_forward", magnetic_head_is_forward_, true);
    nh_p.param("magnetic_tail_is_forward", magnetic_tail_is_forward_, true);
    nh_p.param("distance_magnetic_head_to_robot_center", distance_magnetic_head_to_robot_center, 0.27);
    nh_p.param("distance_magnetic_tail_to_robot_center", distance_magnetic_tail_to_robot_center, 0.27);
    nh_p.param("points_num_consider_detected_magnetic_marker", points_num_consider_detected_magnetic_marker_, 8);
    nh_p.param("param_test", param_test_, 1.0);
    nh_p.param("output_odometry_from_marker", output_odometry_from_marker_, false);
    nh_p.param("x_diff_robot_center", x_diff_robot_center_, 0.0);
    nh_p.param("y_diff_robot_center", y_diff_robot_center_, 0.0);
    nh_p.param("angle_diff_robot_center", angle_diff_robot_center_, 0.0);

    magnetic_head_pose2d_.x = distance_magnetic_head_to_robot_center;
    magnetic_tail_pose2d_.x = -distance_magnetic_tail_to_robot_center;
}

MagneticTfPub::~MagneticTfPub()
{}

inline std::string get_now_time()
{
    const int max_buf_size = 64;
    char buf[max_buf_size];
    std::fill(buf, buf+max_buf_size, 0);
    auto now = std::time(nullptr);
    auto r = std::strftime(buf, max_buf_size, "%F-%H", std::localtime(&now));
    if (!r) throw std::runtime_error("time format error");
    return buf;
}

void MagneticTfPub::TaskSwitchCallback(const std_msgs::HeaderPtr &task_switch_msg)
{
    size_t found_node = task_switch_msg->frame_id.find("magnetic_tf_pub");
    if ( found_node != std::string::npos || task_switch_msg->frame_id.empty() )
    {
        if ( task_switch_msg->seq == 0 )
        {
            //cout << "stop run" << endl;
            LINFO("stop run");
            StopRun();
        }
        else
        {
            //cout << "start run" << endl;
            LINFO("start run");
            run_task_ = true;
            ResetParam();
        }
    }
}

void MagneticTfPub::MagneticHeadCallback(const std_msgs::Int32MultiArrayPtr magnetic_head_msg)
{
    static int continue_detect_marker_times = 0;
    int num_detected_magnetic = 0;

    magnetic_head_pose2d_.y = GetPoseYInRobotBase(magnetic_head_is_forward_, magnetic_head_msg, num_detected_magnetic);

    if ( num_detected_magnetic == 0 ) //未检测到磁条
    {
        head_detected_magnetic_ = false;
        continue_detect_marker_times = 0;
    }
    else //检测到磁条
    {
        head_detected_magnetic_ = true;

        if ( num_detected_magnetic > points_num_consider_detected_magnetic_marker_ )
        {
            LINFO("head: ", magnetic_head_msg->data);
            ++continue_detect_marker_times;
            if (continue_detect_marker_times > 2)
            {
                can_detected_head_marker_ = true;
                if ( head_or_tail_ == NON )
                {
                    LINFO("head detected marker");
                    head_or_tail_ = HEAD;
                }
            }
        }
        else
        {
            can_detected_head_marker_ = false;
            continue_detect_marker_times = 0;
        }
    }
}

void MagneticTfPub::MagneticTailCallback(const std_msgs::Int32MultiArrayPtr magnetic_tail_msg)
{
    static int continue_detect_marker_times = 0;
    int num_detected_magnetic = 0;

    magnetic_tail_pose2d_.y = GetPoseYInRobotBase(magnetic_tail_is_forward_, magnetic_tail_msg, num_detected_magnetic);

    if ( num_detected_magnetic == 0 ) //未检测到磁条
    {
        tail_detected_magnetic_ = false;
        continue_detect_marker_times = 0;
    }
    else //检测到磁条
    {
        tail_detected_magnetic_ = true;

        if ( num_detected_magnetic > points_num_consider_detected_magnetic_marker_ )
        {
            LINFO("tail: ", magnetic_tail_msg->data);
            ++continue_detect_marker_times;
            if ( continue_detect_marker_times > 2 )
            {
                can_detected_tail_marker_ = true;
                if ( head_or_tail_ == NON )
                {
                    LINFO("tail detected marker");
                    head_or_tail_ = TAIL;
                }
            }
        }
        else
        {
            can_detected_tail_marker_ = false;
            continue_detect_marker_times = 0;
        }
    }
}

void MagneticTfPub::OdomCallback(const nav_msgs::OdometryConstPtr odometry_msg)
{
//    odometry_recoder_ = *odometry_msg;
    odometry_recoder_.pose.pose.position.x = odometry_msg->pose.pose.position.x;
    odometry_recoder_.pose.pose.position.y = odometry_msg->pose.pose.position.y;
}

void MagneticTfPub::ResetParam()
{
    head_or_tail_ = NON;

    need_recod_marker_pose_in_odom_ = true;

    count_detected_tail_marker_ = true;
    count_detected_head_marker_ = true;

    detected_tail_marker_times_ = 0;
    detected_head_marker_times_ = 0;

    get_marker_middle_pose_ = false;
}

void MagneticTfPub::StopRun()
{
    run_task_ = false;

    ResetParam();
}

double MagneticTfPub::GetPoseYInRobotBase(bool magnetic_is_forward, const std_msgs::Int32MultiArrayPtr magnetic_msg, int& num_detected_magnetic)
{
    double pose_y_sum = 0.0;

    int signal = 0;
    if ( magnetic_is_forward )
    {
        signal = -1;
    }
    else
    {
        signal = 1;
    }

    int magnetic_msg_size = magnetic_msg->data.size();

    float magnetic_data_middle_index = (magnetic_msg_size - 1) / 2.0;

    for ( int i = 0; i < magnetic_msg_size; ++i )
    {
        if (magnetic_msg->data[i] != 0)
        {
            ++num_detected_magnetic;
            pose_y_sum += signal * (magnetic_data_middle_index - i);
        }
    }

    double pose_y_cm = 0.0;

    if ( num_detected_magnetic == 0 ) //未检测到磁条
    {
        pose_y_cm = 0.0;
    }
    else //检测到磁条
    {
        pose_y_cm = (pose_y_sum / num_detected_magnetic);
    }

    return pose_y_cm * 0.01; //from cm to m
}

double MagneticTfPub::FakeYForControl(double magnetic_y_cm)
{
    double fake_y_for_control_m = magnetic_y_cm * fabs(magnetic_y_cm) * 0.01;// * 2;
    return fake_y_for_control_m;
}

void MagneticTfPub::SendTransform( double x, double y, double theta )
{
    tf::Quaternion q;
    tf::Transform transform;
    static tf::TransformBroadcaster br;

    q.setRPY(0.0, 0.0, theta + AngleToRadian(angle_diff_robot_center_));
    transform.setRotation(q);
    transform.setOrigin( tf::Vector3(x + x_diff_robot_center_, y + y_diff_robot_center_, 0.0) );

    br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "base_link", "magnetic_center"));
}

//计算base_link与磁条的垂足
void MagneticTfPub::GetMagneticPoseInRobot(double& magnetic_tf_x, double& magnetic_tf_y, double& magnetic_tf_theta)
{
    //由两点求直线方程的一般式AX+BY+C=0, A=Y2-Y1, B=X1-X2, C=X2*Y1-X1*Y2;
    //求已知点到已知直线的垂足( (B*B*X-A*B*Y-A*C)/(A*A+B*B), (A*A*Y-A*B*X-B*C)/(A*A+B*B) )

    double dx = magnetic_head_pose2d_.x - magnetic_tail_pose2d_.x;
    double dy = magnetic_head_pose2d_.y - magnetic_tail_pose2d_.y;

    double A = dy;
    double B = -dx;
    double C = magnetic_head_pose2d_.x * magnetic_tail_pose2d_.y - magnetic_tail_pose2d_.x * magnetic_head_pose2d_.y;
    double Apow2_add_Bpow2 = A*A + B*B;

    magnetic_tf_x = -A*C/Apow2_add_Bpow2;
    magnetic_tf_y = -B*C/Apow2_add_Bpow2;
    magnetic_tf_theta = atan2(dy, dx);

    //cout << "magnetic_tf_x: " << magnetic_tf_x << endl;
    //cout << "magnetic_tf_y: " << magnetic_tf_y << endl;
    //cout << "magnetic_tf_theta: " << magnetic_tf_theta << endl;
}

double MagneticTfPub::GetMarkerInOdometryDiff()
{
    static double marker_in_odometry_x = 0.0;
    static double marker_in_odometry_y = 0.0;

    if ( need_recod_marker_pose_in_odom_ )//首次检测到磁条标记，记录odom
    {
        ROS_ERROR("--get magnetic marker--");
        LINFO("--get magnetic marker--");
        marker_in_odometry_x = (odometry_marker_start_.x + odometry_marker_end_.x) / 2.0; //odometry_recoder_.pose.pose.position.x;
        marker_in_odometry_y = (odometry_marker_start_.y + odometry_marker_end_.y) / 2.0; //odometry_recoder_.pose.pose.position.y;

        need_recod_marker_pose_in_odom_ = false;
    }

    double dx = odometry_recoder_.pose.pose.position.x - marker_in_odometry_x;
    double dy = odometry_recoder_.pose.pose.position.y - marker_in_odometry_y;

    double marker_in_odometry_diff = sqrt( pow(dx,2) + pow(dy,2) );

    return marker_in_odometry_diff;
}

void MagneticTfPub::MagneticDetectStatusPub( bool magnetic_detected )
{
    std_msgs::Bool magnetic_detected_msg;
    magnetic_detected_msg.data = magnetic_detected;
    magnetic_detect_status_pub_.publish(magnetic_detected_msg);
}

void MagneticTfPub::Run()
{
    double magnetic_tf_theta = 0.0;
    double magnetic_tf_x = 0.0;
    double magnetic_tf_y = 0.0;

    int no_detected_magnetic_times = 0;
    int no_detected_tail_marker_times = 0;
    int no_detected_head_marker_times = 0;

    const static int rate_hz = 100;

    ros::Rate r(rate_hz);
    while ( ros::ok() )
    {
        ros::spinOnce();

        if ( !run_task_ )
        {
            SendTransform(0.0, 0.0, 0.0);
            r.sleep();
            continue;
        }

        if ( !head_detected_magnetic_ && !tail_detected_magnetic_ ) //前后均未检测到磁条
        {
            MagneticDetectStatusPub(false);
            ROS_WARN("both head and tail do not detected magnetic");
            ++ no_detected_magnetic_times;
            if ( no_detected_magnetic_times > 20*rate_hz )
            {
                StopRun();
            }

            SendTransform(0.0, 0.0, 0.0);
            r.sleep();
            continue;
        }
        else
        {
            MagneticDetectStatusPub(true);

            no_detected_magnetic_times = 0;
            int sign_by_orientation = 0;

            if ( head_or_tail_ == HEAD )
            {
                if ( can_detected_head_marker_ )
                {
                    if ( count_detected_head_marker_ )
                    {
                        detected_head_marker_times_ ++;
                        LINFO("detected_head_marker_times_: " ,detected_head_marker_times_);
                        count_detected_head_marker_ = false;
                        if ( !get_marker_middle_pose_ )
                        {
                            //cout << "get_head_marker_middle_pose_" << endl;
                            LINFO("get_head_marker_middle_pose");
                            odometry_marker_start_.x = odometry_recoder_.pose.pose.position.x;
                            odometry_marker_start_.y = odometry_recoder_.pose.pose.position.y;
                        }
                    }
                    if ( no_detected_head_marker_times > 0 )
                    {
                        ROS_ERROR("no_detected_head_marker_times: %d", no_detected_head_marker_times);
                        LWARN("no_detected_head_marker_times: ", no_detected_head_marker_times);
                    }
                    no_detected_head_marker_times = 0;
                }
                else
                {
                    ++ no_detected_head_marker_times;
                    if ( no_detected_head_marker_times > 8 )
                    {
                        if ( !get_marker_middle_pose_ )
                        {
                            odometry_marker_end_.x = odometry_recoder_.pose.pose.position.x;
                            odometry_marker_end_.y = odometry_recoder_.pose.pose.position.y;
                            get_marker_middle_pose_ = true;
                        }
                        if ( no_detected_head_marker_times > 4*rate_hz )
                        {
                            count_detected_head_marker_ = true;
                        }
                    }
                }
                sign_by_orientation = pow(-1, detected_head_marker_times_-1);
            }
            else if ( head_or_tail_ == TAIL )
            {                
                if ( can_detected_tail_marker_ )
                {
                    if ( count_detected_tail_marker_ )
                    {
                        detected_tail_marker_times_ ++;
                        LINFO("detected_tail_marker_times_: " ,detected_tail_marker_times_);
                        count_detected_tail_marker_ = false;
                        if ( !get_marker_middle_pose_ )
                        {
                            cout << "get_tail_marker_middle_pose_" << endl;
                            LINFO("get_tail_marker_middle_pose");
                            odometry_marker_start_.x = odometry_recoder_.pose.pose.position.x;
                            odometry_marker_start_.y = odometry_recoder_.pose.pose.position.y;
                        }
                    }
                    if ( no_detected_tail_marker_times > 0 )
                    {
                        ROS_ERROR("no_detected_tail_marker_times: %d", no_detected_tail_marker_times);
                        LWARN("no_detected_tail_marker_times: ", no_detected_tail_marker_times);
                    }
                    no_detected_tail_marker_times = 0;
                }
                else
                {
                    ++ no_detected_tail_marker_times;
                    if ( no_detected_tail_marker_times > 10 )
                    {
                        if ( !get_marker_middle_pose_ )
                        {
                            odometry_marker_end_.x = odometry_recoder_.pose.pose.position.x;
                            odometry_marker_end_.y = odometry_recoder_.pose.pose.position.y;
                            get_marker_middle_pose_ = true;
                        }
                        if ( no_detected_tail_marker_times > 4*rate_hz )
                        {
                            count_detected_tail_marker_ = true;
                        }
                    }
                }
                sign_by_orientation = pow(-1, detected_tail_marker_times_);
            }
            else //NON
            {}

            //cout << detected_head_marker_times_  << " : " << sign_by_orientation << endl;

            double marker_in_odometry_diff = 0.0;

            if ( head_or_tail_ != NON && get_marker_middle_pose_ )
            {
                marker_in_odometry_diff = sign_by_orientation * GetMarkerInOdometryDiff();//param_test_
            }

            GetMagneticPoseInRobot(magnetic_tf_x, magnetic_tf_y, magnetic_tf_theta);

            if ( output_odometry_from_marker_ )
            {
                cout << "odometry_from_marker: " << marker_in_odometry_diff*cos(magnetic_tf_theta) << endl;
            }
            double magnetic_tf_x_pub = magnetic_tf_x - marker_in_odometry_diff*cos(magnetic_tf_theta);
            double magnetic_tf_y_pub = magnetic_tf_y - marker_in_odometry_diff*sin(magnetic_tf_theta);

            SendTransform(magnetic_tf_x_pub, magnetic_tf_y_pub, magnetic_tf_theta);
        }

        r.sleep();
    }
}

int main(int argc, char** argv )
{
    // Console Logger
    auto console_logger = std::make_shared<lynx::ConsoleLogger>();
    lynx::Log::Instance()->add_handle(console_logger);
    // File Logger (by open time)

    int sys_return = system("mkdir -p magnetic_logs_tf");
    auto file = "magnetic_logs_tf/" + get_now_time() + ".txt";// 在~/.ros/magnetic_logs/文件夹下
    auto file_logger = std::make_shared<lynx::FileLogger>(file);
    lynx::Log::Instance()->add_handle(file_logger);

    ros::init(argc, argv, "magnetic_tf_pub");
    MagneticTfPub magnetic_tf_pub;
    magnetic_tf_pub.Run();
    return 0;
};
